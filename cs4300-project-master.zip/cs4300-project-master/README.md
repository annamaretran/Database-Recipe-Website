# Group 11

- Towery Emily
- Chen Haping
- McGlynn Nick
- Tran Anna
- Chang Tobie

## To Run

Run recipe_ninja_database.sql file to create associated database
start by opening index.html to follow intended website logic, most pages are inaccessible before login occurs

## Contributions

Emily

- Starter HTML, CSS & Page setup
- Donation page & Javascript
- delete button, save button, logout button & associated php
- login/create account error checking

Nick

- Creation of GitHub Repository and website diagrams
- Organization of preliminary files and website design
- Maintenance on MySQL database, PHP, and HTML files
- Presented Assignment

Tobie

- CSS for index, Explore, My Page, and recipe display pages
- General formatting and aesthetics across website
- Recipe Filter dropdown menu
- Contributed to edit profile functionality

Anna

- CSS/HTML/PHP for explore and mypage
- HTML/PHP for displayrecipe
- Create account error checking
- Creating steps/ingredient table database

Haping

- CSS/HTML/PHP for profile page
- CSS/HTML/PHP for login page
- CSS/HTML/PHP for create account page  
- CSS/HTML for failed login/failed created acocunt page
